#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <QWidget>
#include <QSvgWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QPainter>
#include <QPaintEvent>
#include <QPen>

#define SVG_PATH "C:/Users/user/Desktop/temp/Ground/satellite.svg"
#define PEN_WIDTH 5

class HLine : public QWidget
{
    Q_OBJECT
public:
    HLine(QColor color, QWidget* parent = nullptr) : QWidget(parent) { pen = new QPen(color); }
    ~HLine() { delete pen; }
    void paintEvent(QPaintEvent* event) override;
protected:
    QPen* pen;
};

class VLine : public QWidget
{
    Q_OBJECT
public:
    VLine(QColor color, QWidget* parent = nullptr) : QWidget(parent) { pen = new QPen(color); }
    ~VLine() { delete pen; }
    void paintEvent(QPaintEvent* event) override;
protected:
    QPen* pen;
};

class LDiagonal : public QWidget
{
    Q_OBJECT
public:
    LDiagonal(QColor color, QWidget* parent = nullptr) : QWidget(parent) { pen = new QPen(color); }
    ~LDiagonal() { delete pen; }
    void paintEvent(QPaintEvent* event) override;
protected:
    QPen* pen;
};

class RDiagonal : public QWidget
{
    Q_OBJECT
public:
    RDiagonal(QColor color, QWidget* parent = nullptr) : QWidget(parent) { pen = new QPen(color); }
    ~RDiagonal() { delete pen; }
    void paintEvent(QPaintEvent* event) override;
protected:
    QPen* pen;
};

class SvgIcon : public QPushButton
{
    Q_OBJECT
public:
    SvgIcon(int id_, QWidget* parent = nullptr);
    QString getName() { return name; }
private:
    QString name;
    QSvgWidget* svg;
    QLabel* label;
    QVBoxLayout* layout;
};

#endif // GRAPHICS_H
