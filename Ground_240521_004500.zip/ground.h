#ifndef GROUND_H
#define GROUND_H

#include <QMainWindow>
#include <QMap>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTabBar>
#include <QJsonObject>
#include <QColor>
#include <QDebug>

#include "Map.h"
#include "MapGraphicsView.h"
#include "MapTypes.h"
#include "LocationDisplay.h"
#include "MapViewTypes.h"
#include "GraphicsOverlay.h"
#include "GraphicsOverlayListModel.h"
#include "Graphic.h"
#include "SimpleMarkerSymbol.h"
#include "SimpleLineSymbol.h"
#include "SymbolTypes.h"
#include "Point.h"
#include "GraphicListModel.h"
#include "TextSymbol.h"
#include "CompositeSymbol.h"
#include "SpatialReference.h"

#include "satellite.h"
#include "network.h"
#include "sensor.h"
#include "rescue.h"

using namespace Esri::ArcGISRuntime;

class Ground : public QMainWindow
{
    Q_OBJECT
public:
    explicit Ground(QWidget *parent = nullptr);
    Satellite* getSat(int id_) { return cansat[id_ - 1]; }

public slots:
    void new_location(int id, double lat, double lon);

signals:

private:
    Satellite* cansat[SAT_NUM];

    SvgIcon* sat_button[SAT_NUM];

    Map* m_map;
    MapGraphicsView* m_mapView;
    GraphicsOverlay* m_graphicsOverlay;

    TextSymbol* m_label[SAT_NUM + 1];
    SimpleMarkerSymbol* m_marker[SAT_NUM + 1];
    CompositeSymbol* m_display[SAT_NUM + 1];
    Graphic* m_loc[SAT_NUM + 1];

    QWidget* base;
    QLabel* title;
    QVBoxLayout* mainLayout;
    QHBoxLayout* subLayout;
    QTabWidget* tab;

    NetworkManager* n_manager;
    Sensor* sensor;
    Rescue* rescue;

    void map_setup();
};

#endif // GROUND_H
