#ifndef RESCUE_H
#define RESCUE_H

#include <QWidget>
#include <QLabel>
#include <QJsonObject>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QDateTime>
#include <QMessageBox>
#include <QLineEdit>
#include <QPushButton>

#include "Satellite.h"

class Rescue : public QWidget
{
    Q_OBJECT
public:
    explicit Rescue(QWidget* parent = nullptr);

public slots:
    void received_help(Client* refugee_);
    void pressed();

signals:
    void dispatch(Client* refugee_);

private:
    QGroupBox* infobox[2];
    QVBoxLayout* vertical[3];
    QLabel* info[5];
    QHBoxLayout* horizontal;
    QLineEdit* typein;
    QPushButton* send;

    Client* refugee;
    bool SOS, message_sent;

    int showMessageBox(QString msg);
    int showAskBox(QString msg, QString sub_msg);
};

#endif // RESCUE_H
