// Copyright 2024 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the Sample code usage restrictions document for further information.
//

// Qt headers
#include <QApplication>
#include <QMessageBox>
#include <QScreen>

#include "ArcGISRuntimeEnvironment.h"

#include "ground.h"
#include "server.h"

using namespace Esri::ArcGISRuntime;

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);

    // Use of Esri location services, including basemaps and geocoding, requires
    // either an ArcGIS identity or an API key. For more information see
    // https://links.esri.com/arcgis-runtime-security-auth.

    // 1. ArcGIS identity: An ArcGIS named user account that is a member of an
    // organization in ArcGIS Online or ArcGIS Enterprise.

    // 2. API key: A permanent key that gives your application access to Esri
    // location services. Create a new API key or access existing API keys from
    // your ArcGIS for Developers dashboard (https://links.esri.com/arcgis-api-keys).

    const QString apiKey = QString("AAPK9a4ddd0a21bc48e3b409bdfc4e8a911b91PPz_18FPfK8z5VSiQYf52QCb2PSB2AZk5K4YXDHjDY-wWnryBNIsl8dD8ISnsn");
    if (apiKey.isEmpty()) {
        qWarning() << "Use of Esri location services, including basemaps, requires"
                   << "you to authenticate with an ArcGIS identity or set the API Key property.";
    } else {
        ArcGISRuntimeEnvironment::setApiKey(apiKey);
    }

    // Production deployment of applications built with ArcGIS Maps SDK requires you to
    // license ArcGIS Maps SDK functionality. For more information see
    // https://links.esri.com/arcgis-runtime-license-and-deploy.

    // ArcGISRuntimeEnvironment::setLicense("Place license string in here");

    //  use this code to check for initialization errors
    //  QObject::connect(ArcGISRuntimeEnvironment::instance(), &ArcGISRuntimeEnvironment::errorOccurred, [](const Error& error){
    //    QMessageBox msgBox;
    //    msgBox.setText(error.message);
    //    msgBox.exec();
    //  });

    //  if (ArcGISRuntimeEnvironment::initialize() == false)
    //  {
    //    application.quit();
    //    return 1;
    //  }

    Ground applicationWindow;
    applicationWindow.setMinimumSize(QGuiApplication::primaryScreen()->availableSize() * 2 / 3);
    applicationWindow.showMaximized();
    applicationWindow.show();

    Server* server = new Server();
    for (int i = 1; i <= SAT_NUM; i++)
        QObject::connect(server, SIGNAL(newSocket(int,QTcpSocket*)),
                         applicationWindow.getSat(i), SLOT(newSocket(int,QTcpSocket*)));
    server->start();

    return application.exec();
}
