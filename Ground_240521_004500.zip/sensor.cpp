#include "sensor.h"

Sensor::Sensor(Satellite* def, QWidget* parent)
    : QWidget(parent), sat(def)
{
    vertical = new QVBoxLayout(this);
    this->setLayout(vertical);
    toolbar = new QHBoxLayout(this);

    for (int i = 0; i < SAT_NUM; i++) {
        sat_button[i] = new QPushButton("CanSat0" + QString::number(i + 1), this);
        toolbar->addWidget(sat_button[i], 1);
        connect(sat_button[i], SIGNAL(released()), this, SLOT(sat_pressed()));
    }

    video = new QFrame(this);
    video->setFrameStyle(QFrame::StyledPanel);

    for (int i = 0; i < 4; i++) {
        infobox[i] = new QGroupBox(this);
        infotable[i] = new QVBoxLayout(this);
        infobox[i]->setLayout(infotable[i]);
    }

    int location[9] = {0, 0, 1, 1, 2, 2, 2, 3, 3};
    for (int i = 0; i < 9; i++) {
        info[i] = new QLabel(this);
        infotable[location[i]]->addWidget(info[i]);
    }

    for (int i = 0; i < 3; i++)
        infotable[0]->addWidget(infobox[i + 1]);

    infobox[0]->setTitle(sat->getName());
    infobox[0]->setAlignment(Qt::AlignHCenter);
    refresh();

    auto_sos = new QPushButton("Activate automatic SOS mode", this);
    connect(auto_sos, SIGNAL(released()), this, SLOT(auto_pressed()));

    vertical->addLayout(toolbar);
    vertical->addWidget(video, 3);
    vertical->addWidget(infobox[0], 2);
    vertical->addWidget(auto_sos);
}

Sensor::~Sensor()
{
    libvlc_media_player_release(player);
    libvlc_media_release(media);
    libvlc_release(instance);
}

void Sensor::rtsp_setup()
{
    instance = libvlc_new(0, 0);
    player = libvlc_media_player_new(instance);
    media = libvlc_media_new_location(instance, sat->getUrl().toStdString().c_str());
    libvlc_media_player_set_media(player, media);
    libvlc_media_player_set_hwnd(player, reinterpret_cast<void*>(video->winId()));
    libvlc_media_player_play(player);
    media_start = true;
}

void Sensor::rtsp_change()
{
    if (libvlc_media_player_is_playing(player)) libvlc_media_player_stop(player);
    media = libvlc_media_new_location(instance, sat->getUrl().toStdString().c_str());
    libvlc_media_player_set_media(player, media);
    libvlc_media_player_set_hwnd(player, reinterpret_cast<void*>(video->winId()));
    libvlc_media_player_play(player);
}

void Sensor::refresh()
{
    info[stat]->setText("Status:\t\t" + sat->getSensor("stat"));
    info[time]->setText("Timestamp:\t" + sat->getSensor("time"));
    info[loc]->setText("Location:\t" + sat->getSensor("lat") + "    \t"
                                     + sat->getSensor("lon"));
    info[alt]->setText("Altitude:\t" + sat->getSensor("alt"));
    info[acc]->setText("Acceleration:\t" + sat->getSensor("accx") + "    \t"
                                         + sat->getSensor("accy") + "    \t"
                                         + sat->getSensor("accz"));
    info[gyr]->setText("Gyroscope:\t" + sat->getSensor("gyrx") + "    \t"
                                      + sat->getSensor("gyry") + "    \t"
                                      + sat->getSensor("gyrz"));
    info[temp]->setText("Temperature:\t" + sat->getSensor("temp"));
    info[pres]->setText("Pressure:\t" + sat->getSensor("pres"));
    info[humi]->setText("Humidity:\t" + sat->getSensor("humi"));

    if (!media_start && !sat->getNetwork("ip").isEmpty())
        rtsp_setup();
}

void Sensor::sat_pressed()
{
    QString new_name = static_cast<QPushButton*>(sender())->text();
    if (sat->getName() == new_name) return;

    sat = sat->changeSat(new_name.back().digitValue());
    infobox[0]->setTitle(sat->getName());
    if (!sat->getNetwork("ip").isEmpty()) rtsp_change();
    refresh();
}

