#ifndef NETWORK_H
#define NETWORK_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QScrollArea>
#include <QPushButton>
#include <QDateTime>

#include "graphics.h"
#include "satellite.h"

class NetworkManager : public QWidget
{
    Q_OBJECT
public:
    NetworkManager(Satellite* def, QWidget* parent = nullptr);

public slots:
    void pressed();
    void received_data() { if (sat == static_cast<Satellite*>(sender())) refresh(); }

    void isConnected(int from, int to);
    void isDisconnected(int from, int to);

private:
    enum tag {stat, time, mac, ip, neighbor, client};

    Satellite* sat;

    QPushButton* sat_button[SAT_NUM];

    HLine* onetwo[2];
    VLine* onethree[2];
    RDiagonal* onefour[2];
    LDiagonal* twothree[2];
    VLine* twofour[2];
    HLine* threefour[2];

    QVBoxLayout* vertical;
    QGridLayout* mesh;
    QGroupBox* infobox[4];
    QScrollArea* scrollbox[2];
    QVBoxLayout* infotable[4];
    QLabel* info[6];

    void refresh();
    void refresh_graphics();
};

#endif // NETWORK_H
