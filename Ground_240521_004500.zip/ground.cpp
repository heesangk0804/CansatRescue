#include "ground.h"

Ground::Ground(QWidget *parent)
    : QMainWindow(parent)
{
    this->setWindowTitle("Emergency Rescue Ground Command Centre");
    base = new QWidget(this);
    setCentralWidget(base);

    // Satellites
    for (int i = 0; i < SAT_NUM; i++)
        cansat[i] = new Satellite(i + 1, this);

    // Application title
    title = new QLabel(this);
    title->setText("Emergency Rescue Ground Command Centre");
    title->setAlignment(Qt::AlignCenter);
    title->setFont(QFont("Segoe UI", 15));

    // Map preparation
    map_setup();

    // Create tabs
    tab = new QTabWidget(this);
    n_manager = new NetworkManager(cansat[0], this);
    sensor = new Sensor(cansat[0], this);
    rescue = new Rescue(this);

    tab->addTab(n_manager, "Network Manager");
    tab->addTab(sensor, "Satellite Information");
    tab->addTab(rescue, "Distress Signals");

    tab->setFont(QFont("Segoe UI", 11));
    tab->setElideMode(Qt::ElideRight);

    // Main frame layout
    mainLayout = new QVBoxLayout(this);
    subLayout = new QHBoxLayout(this);
    mainLayout->addWidget(title);
    mainLayout->addLayout(subLayout);
    subLayout->addWidget(m_mapView, 1);
    subLayout->addWidget(tab, 1);

    int spacing = 25;
    mainLayout->setContentsMargins(spacing, spacing / 2, spacing, spacing);
    mainLayout->setSpacing(spacing / 2);
    subLayout->setSpacing(spacing);
    base->setLayout(mainLayout);

    // signal and slot connections
    for (int i = 0; i < SAT_NUM; i++) {
        connect(cansat[i], SIGNAL(received_network()), n_manager, SLOT(received_data()));
        connect(cansat[i], SIGNAL(received_sensor()), sensor, SLOT(received_data()));
        connect(cansat[i], SIGNAL(received_help(Client*)), rescue, SLOT(received_help(Client*)));
        connect(sensor, SIGNAL(autoMode(int)), cansat[i], SLOT(autoMode(int)));
        connect(rescue, SIGNAL(dispatch(Client*)), cansat[i], SLOT(dispatch(Client*)));
        connect(cansat[i], SIGNAL(isConnected(int,int)), n_manager, SLOT(isConnected(int,int)));
        connect(cansat[i], SIGNAL(isDisconnected(int,int)), n_manager, SLOT(isDisconnected(int,int)));
        connect(cansat[i], SIGNAL(new_location(int,double,double)), this, SLOT(new_location(int,double,double)));
    }
}

void Ground::map_setup()
{
    m_map = new Map(BasemapStyle::ArcGISImagery, this);
    m_mapView = new MapGraphicsView(this);
    m_graphicsOverlay = new GraphicsOverlay(this);
    m_mapView->graphicsOverlays()->append(m_graphicsOverlay);

    QColor color[SAT_NUM + 1] = {Qt::red, Qt::green, Qt::cyan, Qt::magenta, Qt::yellow};
    QString label[SAT_NUM + 1] = {"     REFUGEE", "     SAT 1",
                                  "     SAT 2", "     SAT 3", "     SAT 4"};
    SimpleLineSymbol* outline = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, Qt::white, 1);

    for (int i = 0; i <= SAT_NUM; i++) {
        m_label[i] = new TextSymbol(label[i], color[i], 13,
                                    HorizontalAlignment::Left, VerticalAlignment::Middle, this);
        m_label[i]->setFontWeight(FontWeight::Bold);
        m_label[i]->setHaloColor(Qt::white);
        m_label[i]->setHaloWidth(1);
        m_marker[i] = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Circle, color[i], 15, this);
        m_marker[i]->setOutline(outline);
        m_display[i] = new CompositeSymbol(QList<Symbol*>{m_marker[i], m_label[i]}, this);
        m_loc[i] = nullptr;
    }

    m_mapView->setMap(m_map);
    m_mapView->locationDisplay()->start();
    m_mapView->locationDisplay()->setAutoPanMode(LocationDisplayAutoPanMode::Recenter);
}

void Ground::new_location(int id, double lat, double lon)
{
    if (m_loc[id] == nullptr) {
        m_loc[id] = new Graphic(Point(lon, lat, SpatialReference::wgs84()), m_display[id], this);
        m_graphicsOverlay->graphics()->append(m_loc[id]);
    } else {
        m_loc[id]->setGeometry(Point(lon, lat, SpatialReference::wgs84()));
    }
}
