#include "graphics.h"

void HLine::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    pen->setWidth(PEN_WIDTH);
    painter.setPen(*pen);
    painter.drawLine(0, this->size().rheight() / 2, this->size().rwidth(), this->size().rheight() / 2);
}

void VLine::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    pen->setWidth(PEN_WIDTH);
    painter.setPen(*pen);
    painter.drawLine(this->size().rwidth() / 2, 0, this->size().rwidth() / 2, this->size().rheight());
}

void LDiagonal::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    pen->setWidth(PEN_WIDTH);
    painter.setPen(*pen);
    painter.drawLine(0, this->size().rheight(), this->size().rwidth(), 0);
}

void RDiagonal::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    pen->setWidth(PEN_WIDTH);
    painter.setPen(*pen);
    painter.drawLine(0, 0, this->size().rwidth(), this->size().rheight());
}

SvgIcon::SvgIcon(int id, QWidget* parent)
    : QPushButton(parent)
{
    svg = new QSvgWidget(this);
    svg->load(QString(SVG_PATH));

    name = "CanSat0" + QString::number(id);
    label = new QLabel(name, this);
    layout = new QVBoxLayout(this);
    layout->addWidget(svg);
    layout->addWidget(label);

    this->setFixedSize(QSize(80, 100));
    this->setLayout(layout);
}
