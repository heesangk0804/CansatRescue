#include "satellite.h"

QMap<int, Satellite*> Satellite::constellation = {};

Satellite::Satellite(int id_, QObject* parent)
    : QObject(parent), id(id_)
{
    QString id_text = QString::number(id);
    name = "CanSat0" + id_text;
    network["stat"] = sensor["stat"] = "Disconnected";
    constellation[id_] = this;
    socket = nullptr;
}

Satellite* Satellite::getSat(QString mac_)
{
    for (auto iter = constellation.begin(); iter != constellation.end(); iter++)
        if (iter.value()->network["mac"] == mac_) return iter.value();
    return nullptr;
}

QString Satellite::getSatName(QString mac_)
{
    for (auto iter = constellation.begin(); iter != constellation.end(); iter++)
        if (iter.value()->network["mac"] == mac_) return iter.value()->name;
    return "Unknown";
}

QList<Client*> Satellite::getClient()
{
    QList<Client*> result;
    for (auto iter = client.begin(); iter != client.end(); iter++)
        result.append(iter.value());
    return result;
}

void Satellite::newSocket(int id_, QTcpSocket* socket_)
{
    if (id != id_) return;

    socket = socket_;
    network["ip"] = socket->peerAddress().toString();
    network["stat"] = sensor["stat"] = "Connected to satellite";
    url = "rtsp://" + network["ip"] + ":8080/";

    connect(socket, SIGNAL(readyRead()), this, SLOT(readJson()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(socket, SIGNAL(errorOccurred(QAbstractSocket::SocketError)),
            this, SLOT(errorOccurred(QAbstractSocket::SocketError)));

    emit received_network();
    emit received_sensor();
}

void Satellite::disconnected()
{
    clean();
    network["stat"] = sensor["stat"] = "Disconnected";

    emit received_network();
    emit received_sensor();
}

void Satellite::errorOccurred(QAbstractSocket::SocketError)
{
    clean();
    network["stat"] = sensor["stat"] = "Error: " + socket->errorString();

    emit received_network();
    emit received_sensor();
}

void Satellite::clean()
{
    network["time"] = "";
    for (auto iter = neighbors.begin(); iter != neighbors.end(); iter++)
        emit isDisconnected(id, getSat(iter.key())->getId());
    neighbors.clear();
    sensor.clear();
    for (auto iter = client.begin(); iter != client.end(); iter++)
        if (iter.value() != nullptr) delete iter.value();
    client.clear();
}

void Satellite::readJson()
{
    QByteArray buffer = socket->readAll();
    if (buffer[2] != 123) return;

    buffer.remove(0, 2);
    QJsonDocument doc = QJsonDocument::fromJson(buffer);
    if (doc.isNull() || !doc.isObject()) return;

    QJsonObject doc_obj = doc.object();
    QJsonObject msg = doc_obj["msg"].toObject();
    if (msg["sender"].toString() != name || msg["receiver"].toString() != "Base") return;
    data_time = msg["time"].toString();

    if (doc_obj.contains("neighbor")) network_info(doc_obj["neighbor"].toObject());
    if (doc_obj.contains("sensor")) sensor_info(doc_obj["sensor"].toObject());
    if (doc_obj.contains("client")) client_info(doc_obj["client"].toObject());
    if (doc_obj.contains("help")) rescue_info(doc_obj["help"].toObject());
}

void Satellite::network_info(QJsonObject info)
{
    network["stat"] = "Receiving network information";
    network["time"] = data_time;
    network["mac"] = info["node0"].toObject()["MAC"].toString();

    QSet<QString> prev;
    for (auto iter = neighbors.begin(); iter != neighbors.end(); iter++)
        prev.insert(iter.key());

    for (int i = 1; ; i++) {
        QString key = "node" + QString::number(i);
        if (!info.contains(key)) break;

        QString mac_ = info[key].toObject()["MAC"].toString();
        neighbors[mac_] = info[key].toObject()["time"].toString();
        if (prev.contains(mac_)) prev.remove(mac_);
        else if (getSat(mac_) != nullptr) emit isConnected(id, getSat(mac_)->getId());
    }

    for (auto iter = prev.begin(); iter != prev.end(); iter++) {
        neighbors.remove(*iter);
        if (getSat(*iter) != nullptr) emit isDisconnected(id, getSat(*iter)->getId());
    }

    emit received_network();
}

void Satellite::sensor_info(QJsonObject info)
{
    sensor["stat"] = "Receiving sensor information";
    sensor["time"] = data_time;

    QJsonObject gps = info["gps"].toObject();
    QJsonObject imu = info["imu"].toObject();
    QJsonObject bme = info["bme"].toObject();

    sensor["lat"] = QString::number(gps["lat"].toDouble()) + " N";
    sensor["lon"] = QString::number(gps["lon"].toDouble()) + " E";
    sensor["alt"] = QString::number(gps["alt"].toDouble()) + " m above sea level";

    QJsonArray acc = imu["acc"].toArray();
    QJsonArray gyr = imu["gyr"].toArray();

    sensor["accx"] = "[X] " + QString::number(acc[0].toDouble()) + " g";
    sensor["accy"] = "[Y] " + QString::number(acc[1].toDouble()) + " g";
    sensor["accz"] = "[Z] " + QString::number(acc[2].toDouble()) + " g";
    sensor["gyrx"] = "[X] " + QString::number(gyr[0].toDouble()) + " °/sec";
    sensor["gyry"] = "[Y] " + QString::number(gyr[1].toDouble()) + " °/sec";
    sensor["gyrz"] = "[Z] " + QString::number(gyr[2].toDouble()) + " °/sec";

    sensor["temp"] = QString::number(bme["temp"].toDouble()) + " °C";
    sensor["pres"] = QString::number(bme["pres"].toDouble()) + " hPa";
    sensor["humi"] = QString::number(bme["humi"].toDouble()) + " %";

    emit received_sensor();
    emit new_location(id, gps["lat"].toDouble(), gps["lon"].toDouble());
}

void Satellite::client_info(QJsonObject info)
{
    QSet<QString> prev;
    for (auto iter = client.begin(); iter != client.end(); iter++)
        prev.insert(iter.key());

    for (int i = 1; ; i++) {
        QString key = "refug" + QString::number(i);
        if (!info.contains(key)) break;

        QString MAC = info[key].toObject()["MAC"].toString();
        QString ip = info[key].toObject()["ip"].toString();
        if (prev.contains(MAC)) prev.remove(MAC);
        else {
            Client* newClient = new Client();
            newClient->info["parent"] = name;
            newClient->info["ip"] = ip;
            newClient->info["mac"] = MAC;
            client[MAC] = newClient;
        }
    }

    for (auto iter = prev.begin(); iter != prev.end(); iter++) {
        delete client[*iter];
        client.remove(*iter);
    }

    emit received_client();
}

void Satellite::rescue_info(QJsonObject info)
{
    if (info["type"].toString() != "help") return;
    QJsonObject refugee = info["refugee"].toObject();
    QString MAC = refugee["MAC"].toString();

    client[MAC]->help = true;
    client[MAC]->info["time"] = data_time;

    double lat = refugee["gps"].toObject()["lat"].toDouble();
    double lon = refugee["gps"].toObject()["lon"].toDouble();
    client[MAC]->info["lat"] = QString::number(lat) + " N";
    client[MAC]->info["lon"] = QString::number(lon) + " E";

    emit received_help(client[MAC]);
    emit new_location(0, lat, lon);
    showMessageBox("Received SOS signal!", "Please check details in <Distress signal> tab.");
}

void Satellite::autoMode(int id_)
{
    if (id != id_ ) return;
    else if (socket == nullptr) return;
    else if (!socket->isValid()) return;
    else if (socket->state() != QTcpSocket::ConnectedState) return;
    //else if (!autoModeTime.isNull() && QDateTime::currentDateTime() < autoModeTime.addSecs(180))
    //   showMessageBox("Automatic SOS mode cannot be activated for 3 mins after last activation.");
    else {
        int choice = showAskBox("Would you like to activate automatic SOS mode?",
                                "All devices connected to " + name
                                + " will automatically send SOS signal if they do not respond.");
        if (choice == QMessageBox::Yes) {
            bool ok;
            QInputDialog dialog;
            dialog.setFont(QFont("Segoe UI", 11));
            QString text = dialog.getText(nullptr, "Activate automatic SOS mode",
                                                 "Please type in a message to send to the devices:",
                                                 QLineEdit::Normal, "", &ok);
            if (ok && !text.isEmpty()) {
                autoSOS(text);
                showMessageBox("Successfully sent activation command.");
            }
        }
    }
}

void Satellite::autoSOS(QString text)
{
    autoModeTime = QDateTime::currentDateTime();
    QJsonObject msg {{"msg", QJsonObject{{"sender", "Base"}, {"receiver", name},
                                        {"time", autoModeTime.toString("yyyy-MM-dd hh:mm:ss.zzz")}}},
                    {"help", QJsonObject{{"type", "auto"}, {"text", text}}}};
    QByteArray response = QJsonDocument(msg).toJson(QJsonDocument::Compact);
    response.prepend(2, static_cast<unsigned short>(msg.length()));
    socket->write(response);
}

void Satellite::dispatch(Client* client)
{
    if (client->getInfo("parent") != name) return;
    QJsonObject msg {{"msg", QJsonObject{{"sender", "Base"}, {"receiver", name},
                     {"time", QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")}}},
                    {"help", QJsonObject{{"type", "dispatch"}, {"text", client->getInfo("dispatch")},
                     {"refugee", QJsonObject{{"MAC", client->getInfo("mac")}}}}}};
    QByteArray response = QJsonDocument(msg).toJson(QJsonDocument::Compact);
    response.prepend(2, static_cast<unsigned short>(msg.length()));
    socket->write(response);
}

int Satellite::showMessageBox(QString msg, QString sub_msg)
{
    QMessageBox msgbox;
    msgbox.setText(msg);
    if (!sub_msg.isEmpty()) msgbox.setInformativeText(sub_msg);
    msgbox.setFont(QFont("Segoe UI", 11));
    msgbox.setMinimumWidth(1000);
    return msgbox.exec();
}

int Satellite::showAskBox(QString msg, QString sub_msg)
{
    QMessageBox msgbox;
    msgbox.setText(msg);
    if (!sub_msg.isEmpty()) msgbox.setInformativeText(sub_msg);
    msgbox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgbox.setDefaultButton(QMessageBox::No);
    msgbox.setFont(QFont("Segoe UI", 11));
    msgbox.setMinimumWidth(1000);
    return msgbox.exec();
}

