#ifndef SATELLITE_H
#define SATELLITE_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QList>
#include <QMap>
#include <QSet>
#include <QDateTime>
#include <QUrl>
#include <QMessageBox>
#include <QInputDialog>

#define SAT_NUM 4

class Client
{
    friend class Satellite;
public:
    bool sentSOS() { return help; }
    QString getInfo(QString key) { return info[key]; }
    void dispatch(QString msg_) { info["dispatch"] = msg_; }
private:
    Client() {}
    QMap<QString, QString> info;
    bool help = false;
};

class Satellite : public QObject
{
    Q_OBJECT
public:
    Satellite(int id_, QObject* parent = nullptr);
    ~Satellite() { constellation.remove(id); clean(); }

    int getId() { return id; }
    QString getName() { return name; }
    Satellite* changeSat(int id_) { return constellation[id_]; }
    QString getSatName(QString mac_);

    QString getUrl() { return url; }
    QString getNetwork(QString key) { return network[key]; }
    QString getSensor(QString key) { return sensor[key]; }
    QMap<QString, QString> getNeighbor() { return neighbors; }
    QList<Client*> getClient();

public slots:
    void newSocket(int id_, QTcpSocket* socket_);
    void disconnected();
    void errorOccurred(QTcpSocket::SocketError err);
    void readJson();
    void autoMode(int id_);
    void dispatch(Client* refugee);

signals:
    void received_network();
    void received_sensor();
    void received_client();
    void received_help(Client* refugee);
    void isConnected(int from, int to);
    void isDisconnected(int from, int to);
    void new_location(int id_, double lat, double lon);

private:
    static QMap<int, Satellite*> constellation; // id
    Satellite* getSat(QString mac_);

    int id;
    QString name;

    // socket communication
    QTcpSocket* socket;
    QString data_time;

    // network manager
    QMap<QString, QString> neighbors; // mac, last checked
    QMap<QString, QString> network;
    void network_info(QJsonObject info);

    // sensor information
    QString url; // rtsp
    QMap<QString, QString> sensor;
    void sensor_info(QJsonObject info);

    // client information
    QMap<QString, Client*> client; // mac
    void client_info(QJsonObject info);

    // auto SOS mode & dispatch
    QDateTime autoModeTime;
    void autoSOS(QString text);
    void rescue_info(QJsonObject info);

    int showMessageBox(QString msg, QString sub_msg = "");
    int showAskBox(QString msg, QString sub_msg = "");

    void clean();
};

#endif // SATELLITE_H
