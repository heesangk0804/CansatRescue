#ifndef SERVER_H
#define SERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class Server : public QObject
{
    Q_OBJECT
public:
    Server(QObject* parent = nullptr) : QObject(parent) { }
    void start();
public slots:
    void newConnection();
signals:
    void newSocket(int id_, QTcpSocket* socket);
private:
    QTcpServer* server;
};

#endif // SERVER_H
