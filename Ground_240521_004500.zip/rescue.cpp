#include "rescue.h"

Rescue::Rescue(QWidget* parent)
    : QWidget(parent)
{
    vertical[0] = new QVBoxLayout(this);
    this->setLayout(vertical[0]);
    infobox[0] = new QGroupBox("Refugee information", this);
    infobox[0]->setAlignment(Qt::AlignHCenter);
    vertical[1] = new QVBoxLayout(this);
    infobox[0]->setLayout(vertical[1]);

    info[0] = new QLabel("Status:\t\tNo SOS signal received");
    info[1] = new QLabel("Received at:\t");
    info[2] = new QLabel("Location:\t");
    for (int i = 0; i < 3; i++)
        vertical[1]->addWidget(info[i], 1);

    vertical[2] = new QVBoxLayout(this);
    infobox[1] = new QGroupBox("Network information", this);
    infobox[1]->setAlignment(Qt::AlignHCenter);
    infobox[1]->setLayout(vertical[2]);

    info[3] = new QLabel("IP:\t");
    info[4] = new QLabel("MAC:\t");
    vertical[2]->addWidget(info[3], 1);
    vertical[2]->addWidget(info[4], 1);
    vertical[1]->addWidget(infobox[1]);

    horizontal = new QHBoxLayout(this);
    typein = new QLineEdit(this);
    typein->setPlaceholderText("Type in message to send to refugee . . .");
    send = new QPushButton("Send", this);
    horizontal->addWidget(typein);
    horizontal->addWidget(send);
    vertical[1]->addLayout(horizontal, 1);

    vertical[0]->addStretch(1);
    vertical[0]->addWidget(infobox[0], 1);
    vertical[0]->addStretch(1);

    refugee = nullptr;
    connect(send, SIGNAL(released()), this, SLOT(pressed()));
}

void Rescue::received_help(Client* refugee_)
{
    refugee = refugee_;
    info[0]->setText("Status:\t\tReceived SOS signal!!!");
    info[1]->setText("Received at:\t" + refugee->getInfo("time"));
    info[2]->setText("Location:\t" + refugee->getInfo("lat") + "\t" + refugee->getInfo("lon"));
    info[3]->setText("IP:\t" + refugee->getInfo("ip"));
    info[4]->setText("MAC:\t" + refugee->getInfo("mac"));
    infobox[1]->setTitle("Network information (Connected to " + refugee->getInfo("parent") + ")");
}

void Rescue::pressed()
{
    if (refugee == nullptr || !refugee->getInfo("dispatch").isEmpty()
                           || typein->text().simplified().isEmpty()) return;
    int choice = showAskBox("Would you like to send the message?",
                            "You cannot send a message to the refugee more than once.");
    if (choice == QMessageBox::Yes) {
        refugee->dispatch(typein->text());
        emit dispatch(refugee);
        showMessageBox("Dispatch message successfully sent.");
        info[0]->setText("Status:\t\tDispatch message sent to refugee");
    }
}

int Rescue::showMessageBox(QString msg)
{
    QMessageBox msgbox;
    msgbox.setText(msg);
    msgbox.setFont(QFont("Segoe UI", 11));
    msgbox.setMinimumWidth(1000);
    return msgbox.exec();
}

int Rescue::showAskBox(QString msg, QString sub_msg)
{
    QMessageBox msgbox;
    msgbox.setText(msg);
    msgbox.setInformativeText(sub_msg);
    msgbox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgbox.setDefaultButton(QMessageBox::No);
    msgbox.setFont(QFont("Segoe UI", 11));
    msgbox.setMinimumWidth(1000);
    return msgbox.exec();
}
