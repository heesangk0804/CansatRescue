#ifndef SENSOR_H
#define SENSOR_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QGroupBox>
#include <QLabel>
#include <QMessageBox>

typedef __int64 ssize_t;
#include <vlc/vlc.h>

#include "satellite.h"

class Sensor : public QWidget
{
    Q_OBJECT
public:
    Sensor(Satellite* def, QWidget* parent = nullptr);
    ~Sensor();

public slots:
    void sat_pressed();
    void auto_pressed() { emit autoMode(sat->getId()); }
    void received_data() { if (sat == static_cast<Satellite*>(sender())) refresh(); }

signals:
    void autoMode(int id_);

private:
    enum tag {stat, time, loc, alt, acc, gyr, temp, pres, humi};

    Satellite* sat;

    QVBoxLayout* vertical;
    QHBoxLayout* toolbar;
    QPushButton* sat_button[SAT_NUM];

    QGroupBox* infobox[4];
    QVBoxLayout* infotable[4];
    QLabel* info[9];
    QPushButton* auto_sos;

    libvlc_instance_t* instance;
    libvlc_media_player_t* player;
    libvlc_media_t* media;
    QFrame* video;
    bool media_start = false;

    void rtsp_setup();
    void rtsp_change();
    void refresh();
};

#endif // SENSOR_H
