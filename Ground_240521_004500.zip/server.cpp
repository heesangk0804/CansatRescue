#include "server.h"

void Server::start()
{
    server = new QTcpServer(this);
    connect(server, SIGNAL(newConnection()), this, SLOT(newConnection()));
    int res = server->listen(QHostAddress("192.168.1.2"), 2500);
    qDebug() << (res ? "Connection success" : "Connection failure");
}

void Server::newConnection()
{
    while (server->hasPendingConnections()) {
        QTcpSocket* temp = server->nextPendingConnection();
        unsigned int address = temp->peerAddress().toIPv4Address();
        int id_ = 0;
        if ((address & 0xffffff00) == 0xc0a8c700)
            id_ = address & 0xff;
        else if ((address & 0xffff00ff) == 0xc0a80001)
            id_ = (address & 0xff00) >> 8;

        emit newSocket(id_, temp);
    }
}
