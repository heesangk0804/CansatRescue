#include "network.h"

NetworkManager::NetworkManager(Satellite* def, QWidget* parent)
    : QWidget(parent), sat(def)
{
    vertical = new QVBoxLayout(this);
    this->setLayout(vertical);
    mesh = new QGridLayout(this);

    onetwo[0]    = new HLine(Qt::darkGray);     onetwo[1]    = new HLine(Qt::blue);
    onethree[0]  = new VLine(Qt::darkGray);     onethree[1]  = new VLine(Qt::blue);
    onefour[0]   = new RDiagonal(Qt::darkGray); onefour[1]   = new RDiagonal(Qt::blue);
    twothree[0]  = new LDiagonal(Qt::darkGray); twothree[1]  = new LDiagonal(Qt::blue);
    twofour[0]   = new VLine(Qt::darkGray);     twofour[1]   = new VLine(Qt::blue);
    threefour[0] = new HLine(Qt::darkGray);     threefour[1] = new HLine(Qt::blue);

    mesh->addWidget(onetwo[0], 0, 2);
    mesh->addWidget(onethree[0], 1, 1);
    mesh->addWidget(onefour[0], 1, 2);
    mesh->addWidget(twothree[0], 1, 2);
    mesh->addWidget(twofour[0], 1, 3);
    mesh->addWidget(threefour[0], 2, 2);

    int row[] = {0, 0, 2, 2};
    int col[] = {1, 3, 1, 3};

    for (int i = 0; i < SAT_NUM; i++) {
        sat_button[i] = new SvgIcon(i + 1, this);
        sat_button[i]->setFlat(true);
        mesh->addWidget(sat_button[i], row[i], col[i], 1, 1, Qt::AlignCenter);
        connect(sat_button[i], SIGNAL(released()), this, SLOT(pressed()));
    }

    mesh->setColumnStretch(0, 1);
    mesh->setColumnStretch(2, 1);
    mesh->setColumnStretch(4, 1);
    mesh->setRowStretch(1, 2);

    QString box_name[4] = {sat->getName(), "", "Detected Neighbours", "Connected Clients"};
    int location[4] = {0, 0, 1, 1};

    for (int i = 0; i < 4; i++) {
        infobox[i] = new QGroupBox(box_name[i], this);
        infobox[i]->setAlignment(Qt::AlignHCenter);
        infotable[i] = new QVBoxLayout(this);
        infobox[i]->setLayout(infotable[i]);
        info[i] = new QLabel(this);
        infotable[location[i]]->addWidget(info[i]);
    }

    for (int i = 0; i < 2; i++) {
        info[i + 4] = new QLabel(this);
        scrollbox[i] = new QScrollArea(this);
        scrollbox[i]->setWidgetResizable(true);
        scrollbox[i]->setWidget(info[i + 4]);
        infotable[i + 2]->addWidget(scrollbox[i], 1);
        infobox[i + 2]->setMinimumHeight(100);
    }

    infotable[0]->addWidget(infobox[1]);
    infotable[0]->addWidget(infobox[2]);
    infotable[0]->addWidget(infobox[3]);
    refresh();

    vertical->addLayout(mesh);
    vertical->addWidget(infobox[0]);
}

void NetworkManager::refresh()
{
    info[stat]->setText("Status:\t\t" + sat->getNetwork("stat"));
    info[time]->setText("Timestamp:\t" + sat->getNetwork("time"));
    info[mac]->setText("WLAN MAC:\t" + sat->getNetwork("mac"));
    info[ip]->setText("IP:\t\t" + sat->getNetwork("ip"));

    QMap<QString, QString> neighbors = sat->getNeighbor();
    if (neighbors.isEmpty()) info[neighbor]->setText("");
    else {
        QString neighbor_text;
        for (auto iter = neighbors.begin(); iter != neighbors.end(); iter++)
            neighbor_text += sat->getSatName(iter.key()) + "    \t(Last checked at " + iter.value() + ")\n";
        neighbor_text.removeLast();
        qDebug() << neighbor_text;
        info[neighbor]->setText(neighbor_text);
    }

    QList<Client*> clients = sat->getClient();
    if (clients.isEmpty()) info[client]->setText("");
    else {
        QString client_text;
        for (int i = 0; i < clients.size(); i++)
            client_text += "IP: " + clients[i]->getInfo("ip") + "    \tMAC: " + clients[i]->getInfo("mac") + "\n";
        client_text.removeLast();
        qDebug() << client_text;
        info[client]->setText(client_text);
    }
}

void NetworkManager::isConnected(int from, int to)
{
    if ((from == 1 && to == 2) || (from == 2 && to == 1)) {
        mesh->replaceWidget(onetwo[0], onetwo[1]);
    } else if ((from == 1 && to == 3) || (from == 3 && to == 1)) {
        mesh->replaceWidget(onethree[0], onethree[1]);
    } else if ((from == 1 && to == 4) || (from == 4 && to == 1)) {
        mesh->replaceWidget(onefour[0], onefour[1]);
    } else if ((from == 2 && to == 3) || (from == 3 && to == 2)) {
        mesh->replaceWidget(twothree[0], twothree[1]);
    } else if ((from == 2 && to == 4) || (from == 4 && to == 2)) {
        mesh->replaceWidget(twofour[0], twofour[1]);
    } else if ((from == 3 && to == 4) || (from == 4 && to == 2)) {
        mesh->replaceWidget(threefour[0], threefour[1]);
    }
}

void NetworkManager::isDisconnected(int from, int to)
{
    if ((from == 1 && to == 2) || (from == 2 && to == 1)) {
        mesh->replaceWidget(onetwo[1], onetwo[0]);
    } else if ((from == 1 && to == 3) || (from == 3 && to == 1)) {
        mesh->replaceWidget(onethree[1], onethree[0]);
    } else if ((from == 1 && to == 4) || (from == 4 && to == 1)) {
        mesh->replaceWidget(onefour[1], onefour[0]);
    } else if ((from == 2 && to == 3) || (from == 3 && to == 2)) {
        mesh->replaceWidget(twothree[1], twothree[0]);
    } else if ((from == 2 && to == 4) || (from == 4 && to == 2)) {
        mesh->replaceWidget(twofour[1], twofour[0]);
    } else if ((from == 3 && to == 4) || (from == 4 && to == 2)) {
        mesh->replaceWidget(threefour[1], threefour[0]);
    }
}

void NetworkManager::pressed()
{
    QString new_name = static_cast<SvgIcon*>(sender())->getName();
    if (sat->getName() == new_name) return;
    sat = sat->changeSat(new_name.back().digitValue());
    infobox[0]->setTitle(sat->getName());
    refresh();
}
