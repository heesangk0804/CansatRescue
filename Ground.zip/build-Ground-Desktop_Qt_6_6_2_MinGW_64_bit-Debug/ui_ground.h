/********************************************************************************
** Form generated from reading UI file 'ground.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GROUND_H
#define UI_GROUND_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Ground
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_2;
    QLabel *status;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_3;
    QLabel *location;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_4;
    QSpinBox *duration;
    QPushButton *enter;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Ground)
    {
        if (Ground->objectName().isEmpty())
            Ground->setObjectName("Ground");
        Ground->resize(696, 471);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Ignored);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Ground->sizePolicy().hasHeightForWidth());
        Ground->setSizePolicy(sizePolicy);
        centralwidget = new QWidget(Ground);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setEnabled(true);
        centralwidget->setMinimumSize(QSize(400, 300));
        QFont font;
        font.setPointSize(12);
        centralwidget->setFont(font);
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(70, 60, 551, 351));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(25);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(25, 25, 25, 25);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName("label");
        QFont font1;
        font1.setPointSize(15);
        label->setFont(font1);
        label->setAlignment(Qt::AlignCenter);
        label->setIndent(0);

        horizontalLayout_4->addWidget(label);


        verticalLayout->addLayout(horizontalLayout_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Preferred);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName("label_2");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);

        horizontalLayout_5->addWidget(label_2);

        status = new QLabel(verticalLayoutWidget);
        status->setObjectName("status");

        horizontalLayout_5->addWidget(status);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName("label_3");
        sizePolicy1.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy1);

        horizontalLayout_6->addWidget(label_3);

        location = new QLabel(verticalLayoutWidget);
        location->setObjectName("location");

        horizontalLayout_6->addWidget(location);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName("label_4");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy2);

        horizontalLayout_7->addWidget(label_4);

        duration = new QSpinBox(verticalLayoutWidget);
        duration->setObjectName("duration");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(duration->sizePolicy().hasHeightForWidth());
        duration->setSizePolicy(sizePolicy3);
        duration->setMinimumSize(QSize(100, 0));

        horizontalLayout_7->addWidget(duration);

        enter = new QPushButton(verticalLayoutWidget);
        enter->setObjectName("enter");
        sizePolicy3.setHeightForWidth(enter->sizePolicy().hasHeightForWidth());
        enter->setSizePolicy(sizePolicy3);

        horizontalLayout_7->addWidget(enter);


        verticalLayout->addLayout(horizontalLayout_7);

        Ground->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Ground);
        statusbar->setObjectName("statusbar");
        Ground->setStatusBar(statusbar);

        retranslateUi(Ground);

        QMetaObject::connectSlotsByName(Ground);
    } // setupUi

    void retranslateUi(QMainWindow *Ground)
    {
        Ground->setWindowTitle(QCoreApplication::translate("Ground", "Ground", nullptr));
        label->setText(QCoreApplication::translate("Ground", "Emergency Rescue Ground Command Centre", nullptr));
        label_2->setText(QCoreApplication::translate("Ground", "Status:   ", nullptr));
        status->setText(QString());
        label_3->setText(QCoreApplication::translate("Ground", "Location:", nullptr));
        location->setText(QString());
        label_4->setText(QCoreApplication::translate("Ground", "Expected duration until arrival:", nullptr));
        enter->setText(QCoreApplication::translate("Ground", "Enter", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Ground: public Ui_Ground {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GROUND_H
