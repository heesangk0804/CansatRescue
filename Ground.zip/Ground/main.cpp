#include "ground.h"
#include "socket.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Socket socket;
    Ground ground;

    QObject::connect(&socket, &Socket::conn_send, &ground, &Ground::conn_recv);
    QObject::connect(&socket, &Socket::disc_send, &ground, &Ground::disc_recv);
    QObject::connect(&socket, &Socket::erro_send, &ground, &Ground::erro_recv);

    QObject::connect(&socket, &Socket::help_send, &ground, &Ground::help_recv);
    QObject::connect(&ground, &Ground::resp_send, &socket, &Socket::resp_recv);

    socket.connect();

    ground.show();
    return a.exec();
}
