#include "ground.h"
#include "ui_ground.h"

Ground::Ground(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Ground)
{
    ui->setupUi(this);
    QWidget::connect(ui->enter, &QPushButton::pressed, this, &Ground::disp_dur);
    ui->status->setText("Disconnected");
    ui->location->setText("");
}

Ground::~Ground()
{
    delete ui;
}

void Ground::conn_recv()
{
    sos = false;
    sent = false;
    ui->status->setText("Connected");
    ui->location->setText("");
}

void Ground::disc_recv()
{
    sos = false;
    sent = false;
    ui->status->setText("Disconnected");
    ui->location->setText("");
}

void Ground::erro_recv()
{
    sos = false;
    sent = false;
    ui->status->setText("Error occurred during connection");
    ui->location->setText("");
}

void Ground::help_recv(QJsonArray location)
{
    sos = true;
    if (!sent) {
        ui->status->setText("Received SOS!");
        if (!location.isEmpty()){
            QString lat = location[0].toString();
            QString lon = location[1].toString();
            ui->location->setText(lat + " N " + lon + " E");
        } else {
            ui->location->setText("Unknown");
        }
    }
}

void Ground::disp_dur()
{
    if (!sos || sent) return;

    sent = true;
    emit resp_send(ui->duration->value());
    ui->status->setText("Rescue message sent");
}
