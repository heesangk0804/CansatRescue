#ifndef SOCKET_H
#define SOCKET_H

#include <QObject>
#include <QTcpSocket>
#include <QTcpServer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
#include <QString>

class Socket : public QObject
{
    Q_OBJECT

public:
    explicit Socket(QObject* parent = nullptr) : QObject(parent) {}
    ~Socket();
    void connect();

public slots:
    void connected();
    void disconnected();
    void error();
    void ready();
    void resp_recv(int duration);

signals:
    void conn_send();
    void disc_send();
    void erro_send();
    void help_send(QJsonArray location);

private:
    QString host = "192.168.2.19";
    int port = 2500;

    QTcpSocket* baseclient = nullptr;
    QTcpServer* server = nullptr;
};

#endif // SOCKET_H
