#ifndef GROUND_H
#define GROUND_H

#include <QMainWindow>
#include <QString>
#include <QJsonValue>
#include <QJsonArray>

QT_BEGIN_NAMESPACE
namespace Ui {
class Ground;
}
QT_END_NAMESPACE

class Ground : public QMainWindow
{
    Q_OBJECT

public:
    Ground(QWidget *parent = nullptr);
    ~Ground();

public slots:
    void conn_recv();
    void disc_recv();
    void erro_recv();
    void help_recv(QJsonArray location);
    void disp_dur();

signals:
    void resp_send(int duration);

private:
    Ui::Ground *ui;
    bool sos = false;
    bool sent = false;
};

#endif // GROUND_H
