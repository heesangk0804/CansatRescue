// For more information about the code, visit the site below:
// https://coding-chobo.tistory.com/42

#include "socket.h"

Socket::~Socket()
{
    delete baseclient;
    delete server;
}

void Socket::connect()
{
    server = new QTcpServer(this);
    QObject::connect(server, &QTcpServer::newConnection, this, &Socket::connected);
    server->listen(QHostAddress(host), port);
}

void Socket::connected()
{
    emit conn_send();
    baseclient = server->nextPendingConnection();
    QObject::connect(baseclient, &QTcpSocket::readyRead, this, &Socket::ready);
    QObject::connect(baseclient, &QTcpSocket::disconnected, this, &Socket::disconnected);
    QObject::connect(baseclient, &QTcpSocket::errorOccurred, this, &Socket::error);
}

void Socket::disconnected()
{
    emit disc_send();
}

void Socket::error()
{
    emit erro_send();
}

void Socket::ready()
{
    QByteArray buffer = baseclient->readAll();
    if (buffer[2] != 123) emit erro_send();

    buffer.remove(0, 2);
    QJsonDocument doc = QJsonDocument::fromJson(buffer);
    if (doc.isNull() || !doc.isObject()) emit erro_send();

    QJsonObject sos = doc.object()["msg"].toObject();
    if (sos.contains("help") && sos["help"].toString() == "true")
        emit help_send(sos["gps"].toArray());
}

void Socket::resp_recv(int duration)
{
    QJsonObject resp_json {{"msg", QJsonObject {{"sender", "base"}, {"receiver", "rpi1"}, {"dispatch", "true"}, {"duration", duration}}}};
    QByteArray response = QJsonDocument(resp_json).toJson();
    response.prepend(static_cast<unsigned short>(resp_json.length()));
    baseclient->write(response);
}
