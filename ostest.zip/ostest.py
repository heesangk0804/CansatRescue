import os
import re
import json

MAC_PTN = '[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}'
IPv4_PTN = '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+'
neighbor_list = [] #[0]: wlan1_MAC, [1]: last seen time, [2]: list of bat0_MAC connected, [2][N][2]: list of bat0_IP
apclient_list = []

WLAN_MAC_LIST = [
  '0c:88:2b:00:8c:e4', '0c:88:2b:00:8c:df', '0c:88:2b:00:8c:cd', '3c:9b:d6:ec:46:15',
  '0c:88:2b:00:8c:cf', '0c:88:2b:00:8c:d5', '0c:88:2b:00:Bc:f2', 'Oc:88:2b:00:8c:e3'
]

BAT0_IP_LIST = [
  '192.168.199.1', '192.168.199.2', '192.168.199.3', '192.168.199.4'
]


default_msg_obj = {          #also same with meshinfo_msg packet
  "msg": {
    "sender": "CanSat01",
    "receiver": None,
    "time": None
  }
}

nodeX_info_obj = {          #also same with meshinfo_msg packet
  "ip": None,  
  "time": None,
  "wlan1_MAC": None,
  "bat0_MAC": None
}

refugX_info_obj = {          #also same with meshinfo_msg packet
  "ip": None,  
  "MAC": None,
}



'''
batn_str = """[B.A.T.M.A.N. adv 2022.3, MainIF/MAC: wlan1/0c:88:2b:00:8c:cf (bat0/06:c7:df: 54:bb:2e BATMAN_IV)]
IF               Neighbor                  last-seen
         wlan1       0c:88:2b:00:8c:df       1.510s
         wlan1       0c:88:2b:00:8c:e3       0.330s"""
         
battg_str = """[B.A.T.M.A.N. adv 2022.3, MainIF/MAC: wlan1/0c:88:2b:00:8c:cf (bat0/06:c7:df: 54:bb:2e BATMAN_IV)]
Client                   VID Flags Last ttvn       Via        ttvn     (CRC        )
* 12:02:c9:92:24:2f     0 [....] (   6) 0c:88:2b:00:8c:df (   6) (0xe4887d28)
* 01:00:5e:00:00:09    -1 [....] (  32) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b)
  01:00:5e:00:00:09    -1 [....] (   3) 0c:88:2b:00:8c:df (   6) (0x752dccf2) 
* 33:33:00:00:00:fb    -1 [....] (   8) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b)
  33:33:00:00:00:fb    -1 [....] (   6) 0c:88:2b:00:8c:df (   6) (0x752dccf2)
* 01:00:5e:00:00:01    -1 [....] (   8) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b)
  01:00:5e:00:00:01    -1 [....] (   6) 0c:88:2b:00:8c:df (   6) (0x752dccf2)
* 82:c3:b0:29:89:0b    -1 [....] (   3) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b) 
* 33:33:ff:21:a7:53    -1 [....] (   8) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b) 
* 12:02:c9:92:24:2f    -1 [....] (   3) 0c:88:2b:00:8c:df (   6) (0x752dccf2) 
* 01:00:5e:00:00:fb    -1 [....] (   8) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b) 
  01:00:5e:00:00:fb    -1 [....] (   6) 0c:88:2b:00:8c:df (   6) (0x752dccf2) 
* 33:33:ff:ac:c7:24    -1 [....] (   6) 0c:88:2b:00:8c:df (   6) (0x752dccf2) 
* 82:c3:b0:29:89:0b     0 [....] (   8) 0c:88:2b:00:8c:e3 (  32) (0x8c652cd3) 
* 33:33:00:00:00:01    -1 [....] (   3) 0c:88:2b:00:8c:e3 (  32) (0xb0e7f70b) 
  33:33:00:00:00:01    -1 [....] (   3) 0c:88:2b:00:8c:df (   6) (0x752dccf2)
"""

arpn_str = """Address                   HWtype  HWaddress             Flags Mask          If
ace
192.168.199.70            ether    12:02:c9:92:24:2f    C                   ba
t0
192.168.199.4             ether    82:c3:b0:29:89:0b    C                   ba
t0
192.168.199.2             ether    12:02:c9:92:24:2f    C                   ba
t0
192.168.0.1               ether    88:36:6c:ea:f7:84    C                   wl
an0
192.168.199.5             ether    72:b3:7d:3c:e1:13    C                   ba
t0
192.168.199.35            ether    82:c3:b0:29:89:0b    C                   ba"""


Address                   HWtype  HWaddress             Flags Mask          If
142.250.207.106                   (incomplete)                                 bat0
192.168.1.53              ether   8c:17:59:d5:9c:e2     C                   wlan2
8.8.8.8                           (incomplete)                              bat0
121.53.214.187                    (incomplete)                              bat0
142.250.206.202                   (incomplete)                              bat0
192.168.199.99            ether   b6:4a:a4:dd:1d:bd     C                   bat0
192.168.1.30              ether   ce:ee:85:d4:1f:28     C                   wlan2
142.250.206.234                   (incomplete)                              bat0


'''         
         
#batn_str = os.popen('sudo batctl n')  #list of wlan1's neighbor mesh nodes(1 hop)
batn_str = open("sudo_batctl_n.txt", 'r')
#print(batn_str)
#Step 1. wlan1 MAC
while True:
  p = batn_str.readline()
  if p == '' : break
  checkwlan = re.match('wlan1', p.strip())
  if checkwlan:
      wlann_MAC = re.findall(MAC_PTN, p.strip())
      wlann_time = re.findall('[0-9]+\.[0-9]+s', p.strip())
      neighbor_list.append([wlann_MAC[0], wlann_time[0], []])
#print(neighbor_list)

#Step 2. bat0 MAC
#battg_str = os.popen('sudo batctl tg')  #list of wlan1's transport global mesh nodes: wlan1 -> bat0
battg_str = open("sudo_batctl_tg.txt", 'r')
#print(battg_str)
while True:
  q = battg_str.readline()
  #print(q)
  if q == '' : break
  for wlann_MAC in neighbor_list:
    #print("find " + wlann_MAC[0])
    checkbatMac = q.strip().find(wlann_MAC[0])
    if checkbatMac != -1:
        batn_MAC = re.findall(MAC_PTN, q.strip())
        batn_MAC.remove(wlann_MAC[0])
        wlann_MAC[2].extend(batn_MAC)
        set_batn_MAC = set(wlann_MAC[2])
        wlann_MAC[2] = list(set_batn_MAC)

for wlann_MAC in neighbor_list:
  batn_MAC_list = wlann_MAC[2]
  wlann_MAC[2] = []
  for batn_MAC in batn_MAC_list:
    wlann_MAC[2].append([batn_MAC, []])     
  
print("\nStep 2 Result:")
for neighbor in neighbor_list:
  print(neighbor)


#arpn_str = os.popen('arp -n')
arpn_str = open("arp_-n.txt", 'r')
#Step 3. bat0 IP
#print(arpn_str)  #list of bat0 MAC -> bat0 IP Address (ARP)
while True:
  r = arpn_str.readline()
  #print(r)
  if r == '' : break
  
  if r.strip().find('wlan2') != -1:
    client_MAC = re.findall(MAC_PTN, r.strip())
    client_IP = re.findall(IPv4_PTN, r.strip())
    apclient_list.append([client_IP[0], client_MAC[0]])

  
  for wlann_MAC in neighbor_list:
    for batn_MAC in wlann_MAC[2]:
      #print("find " + batn_MAC[0])
      if r.strip().find(batn_MAC[0]) != -1:
        batn_IP = re.findall(IPv4_PTN, r.strip())
        #print(batn_IP)
        batn_MAC[1].append(batn_IP[0])

print("\nStep 3 Result:")
for neighbor in neighbor_list:
  print(neighbor)
print("apclient list:")
for client in apclient_list:
  print(client)
    

obj = default_msg_obj
obj["neighbor"] = {}
node_num = 0
for neighbor in neighbor_list:
  for batn_MAC in neighbor[2]:
    for BAT0_IP in BAT0_IP_LIST:
      if BAT0_IP in batn_MAC[1]:
        print("Indices : ", neighbor_list.index(neighbor), neighbor[2].index(batn_MAC), "for", BAT0_IP)
        node_num = node_num + 1
        nodeX_key = "node"+str(node_num)
        obj["neighbor"][nodeX_key] = nodeX_info_obj
        nodeX_info_obj.update({}.fromkeys(nodeX_info_obj, None))
        print("nodeX template : "+str(nodeX_info_obj))
        print("New Node appended: " + str(obj["neighbor"]))
        obj["neighbor"]["node"+str(node_num)]["ip"] = BAT0_IP
        obj["neighbor"]["node"+str(node_num)]["time"] = neighbor[1]
        obj["neighbor"]["node"+str(node_num)]["wlan1_MAC"] = neighbor[0]
        obj["neighbor"]["node"+str(node_num)]["bat0_MAC"] = batn_MAC[0]
        print("New Node appended: " + str(obj["neighbor"]))

obj["client"] = {}
refug_num = 0
for client in apclient_list:
  refug_num = refug_num + 1
  refugX_key = "refug"+str(refug_num)
  obj["client"][refugX_key] = refugX_info_obj 
  refugX_info_obj.update({}.fromkeys(refugX_info_obj, None))
  obj["client"][refugX_key]["ip"] = client[0]
  obj["client"][refugX_key]["MAC"] = client[1]
  
print("\nFinal message obj:")
for key in obj.keys():
  value = obj[key]
  print(key, value)

data = json.dumps(obj)
l = len(data)
print(data)

